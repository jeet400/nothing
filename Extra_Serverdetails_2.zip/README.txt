Note: all files and paths are located in the /var/www/pterodactyl/ directory


Upload ServerDetailsBlock.tsx in the folder resources/scripts/components/server

----------------------------------------------------------------------------------------

Run "cd /var/www/pterodactyl && yarn run build:production && chown -R www-data:www-data *" in the SSH

If you got a error like "Command 'yarn' not found", execute the following in the SSH (this might take some time):
curl -sL https://deb.nodesource.com/setup_14.x | sudo -E bash - && sudo apt-get install -y nodejs && npm i -g yarn && cd /var/www/pterodactyl && yarn install

Then run "cd /var/www/pterodactyl && yarn run build:production && chown -R www-data:www-data *" again


Order ID: 00000